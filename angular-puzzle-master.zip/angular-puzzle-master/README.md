angular-puzzle
==============

Simple puzzle games made with AngularJS to demostrate its awesome features, simplicity and power.

Take a look at the demo [pdanis.github.com/angular-puzzle](http://pdanis.github.com/angular-puzzle/ "demo") and have fun ;-)
